package com.example.aistudy.utils

/**
 * An enum class representing the possible states of a search app bar.
 * It is used to control the appearance and behavior of a search app bar component
 * within the UI, facilitating a more dynamic and responsive user interface.
 */
enum class SearchAppBarState {
    OPENED,
    CLOSED,
    TRIGGERED
}