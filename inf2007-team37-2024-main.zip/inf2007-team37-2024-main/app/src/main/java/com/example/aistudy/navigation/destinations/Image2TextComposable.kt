package com.example.aistudy.navigation.destinations

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.example.aistudy.ui.screens.Image2Text.Image2TextScreen
import com.example.aistudy.ui.viewmodels.SharedViewModel
import com.example.aistudy.utils.Constants.IMAGE2TEXT_SCREEN

/**
 * Configures the navigation composable for the Image to Text screen, integrating it into the navigation graph.
 */

fun NavGraphBuilder.Image2TextComposable(
    sharedViewModel: SharedViewModel,
    navController: NavHostController
) {
    composable(route = IMAGE2TEXT_SCREEN) { backStackEntry ->
        Image2TextScreen(
            navController = navController,
            sharedViewModel = sharedViewModel,
        )
    }
}
