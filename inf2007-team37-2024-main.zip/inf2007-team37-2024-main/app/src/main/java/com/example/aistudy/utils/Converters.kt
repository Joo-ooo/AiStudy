package com.example.aistudy.utils

import androidx.room.TypeConverter
import com.example.aistudy.data.notecontent.ContentItem
import com.example.aistudy.data.notecontent.ContentSerializers
import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.reflect.TypeToken
import com.google.gson.Gson
import kotlinx.serialization.encodeToString
import java.util.*

/**
 * A collection of type converters for the Room database, facilitating the
 * conversion between complex types and a form that can be stored in the database.
 */
class Converters {
    /**
     * Converts a timestamp (in milliseconds since the start) to a Date object.
     * @param value The timestamp to convert.
     * @return The corresponding Date object, or null if the input is null.
     */
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    /**
     * Converts a Date object to a timestamp (milliseconds since the start).
     * @param date The Date object to convert.
     * @return The corresponding timestamp, or null if the input is null.
     */
    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time?.toLong()
    }

    /**
     * Converts a UUID to its string representation.
     * @param uuid The UUID to convert.
     * @return The string representation of the UUID, or null if the input is null.
     */
    @TypeConverter
    fun fromUUID(uuid: UUID?): String? {
        return uuid?.toString()
    }

    /**
     * Converts a string representation of a UUID to a UUID object.
     * @param string The string to convert.
     * @return The corresponding UUID object, or null if the input is null.
     */
    @TypeConverter
    fun uuidFromString(string: String?): UUID? {
        return string?.let { UUID.fromString(string) }
    }

    /**
     * A nested class dedicated to converting between a list of ContentItem objects
     * and a JSON string representation, for storing complex data types in the database.
     */
    class ContentItemConverter {
        /**
         * Converts a list of ContentItem objects to a JSON string.
         * @param value The list of ContentItem objects to convert.
         * @return A JSON string representing the list of items.
         */
        @TypeConverter
        fun fromContentItemList(value: List<ContentItem>?): String =
            ContentSerializers.json.encodeToString(value)

        /**
         * Converts a JSON string back into a list of ContentItem objects.
         * @param value The JSON string to convert.
         * @return A list of ContentItem objects represented by the JSON string.
         */
        @TypeConverter
        fun toContentItemList(value: String): List<ContentItem>? =
            ContentSerializers.json.decodeFromString(value)
    }

}
