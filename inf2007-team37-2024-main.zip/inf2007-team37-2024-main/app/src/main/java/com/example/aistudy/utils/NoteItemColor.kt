package com.example.aistudy.utils

import androidx.compose.ui.graphics.Color
import com.example.aistudy.ui.theme.*

/**
 * Determines a color for a note item based on its index.
 *
 * This function selects a color from a predefined list to ensure visual variety
 * and aesthetic appeal in a list or grid of note items. It uses the modulo operator
 * to cycle through the list based on the index, allowing for a repeating pattern
 * of colors if the number of items exceeds the number of available colors.
 *
 * @param index The index of the note item in the list or grid.
 * @return A Color object corresponding to the calculated position in the list of colors.
 */
fun noteItemColor(index: Int): Color {
    val listOfColors = listOf<Color>(
        RichBrilliantLavender, LightSalmonPink, LightGreen, PastelYellow, Waterspout, PaleViolet
    )

    val colorIndex = index % listOfColors.size

    return listOfColors[colorIndex]
}