package com.example.aistudy.navigation.destinations

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.example.aistudy.ui.screens.splash.SplashScreen
import com.example.aistudy.utils.Constants.SPLASH_SCREEN

/**
 * Extension function on NavGraphBuilder to add a Splash Screen composable to the navigation graph.
 * The Splash Screen is the initial screen shown to the user, generally used to display branding or
 * load resources. After its intended display duration or completion of initial setup, it navigates
 * to the List Screen.
 */
fun NavGraphBuilder.splashComposable(
    navigateToListScreen: () -> Unit
) {
    composable(route = SPLASH_SCREEN) {
        SplashScreen(navigateToListScreen = navigateToListScreen)
    }
}