package com.example.aistudy.data.models

/**
 * This data class defines the structure of an AR model, including its name, file path, optimal viewing distance, and description.
 */

data class ARModel(
    val modelName: String,
    val modelPath: String,
    val distance: Float,
    val modelDesc: String
)
