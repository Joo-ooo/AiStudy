package com.example.aistudy.utils

import java.text.SimpleDateFormat
import java.util.*

/**
 * Converts a Date object to a string representation based on a specified format.
 *
 * @param date The Date object to be converted. Can be null.
 * @return A string representation of the provided Date object following the format
 * "hour:minute AM/PM, Month day year" (e.g., "3:45 PM, Jan 01 2020"). Returns null if the input date is null.
 */
fun dateToString(date: Date?): String? {
    val pattern = "h:mm a, MMM dd yyyy";
    val simpleDateFormat = SimpleDateFormat(pattern, Locale.ENGLISH);
    return date?.let { simpleDateFormat.format(it) }
}

/**
 * Converts a string representation of a date and time back into a Date object.
 *
 * @param str The string to be converted into a Date object. Assumes the string follows
 * the format "hour:minute AM/PM, Month day year" (e.g., "3:45 PM, Jan 01 2020").
 * @return The Date object represented by the input string. May return null if the string
 * does not match the expected format or if parsing fails.
 */
fun stringToDate(str: String): Date? {
    val simpleDateFormat = SimpleDateFormat("h:mm a, MMM dd yyyy", Locale.ENGLISH)
    return simpleDateFormat.parse(str)
}