package com.example.aistudy.utils

/**
 * An object that holds constant values used throughout the application.
 * These constants include database names, table names, screen routes,
 * argument keys for navigation, and configuration parameters.
 */
object Constants {
    // Database constants
    const val DATABASE_NAME = "notes_database"
    const val DATABASE_TABLE = "notes_table"
    const val CAT_TABLE = "categories_table"
    const val TSC_TABLE = "transcript_table"

    // Screen route constants for navigation
    const val SPLASH_SCREEN = "splash"
    const val LIST_SCREEN = "list/{action}"
    const val NOTE_SCREEN = "note/{noteId}"
    const val SPEECH2TEXT_SCREEN = "speech2text/{transcriptId}"

    // Argument keys used in navigation routes
    const val LIST_ARGUMENT_KEY = "action"
    const val NOTE_ARGUMENT_KEY = "noteId"

    // Argument keys used in navigation routes
    const val NOTE_PAGE_SIZE = 5   // Pagination size for notes

    // Additional screen route constants
    const val CHATBOT_SCREEN = "chatbot"
//  const val SPEECH2TEXT_SCREEN = "speech2text"
    const val IMAGE2TEXT_SCREEN = "image2text"
    const val AR_SCREEN = "augmentedreality"

}