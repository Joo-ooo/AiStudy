package com.example.aistudy.utils

import androidx.compose.ui.unit.dp

// defines the standard dimensions throughout the app
val APP_BAR_HEIGHT = 56.dp
val SEARCH_TEXT_FIELD_HEIGHT = 50.dp