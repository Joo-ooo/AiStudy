package com.example.aistudy.utils

/**
 * A singleton object that holds global variables for the application.
 * It is used to manage application-wide state variables and settings.
 */
object GlobalVariable {

    var hasNotificationPermission: Boolean = false
}