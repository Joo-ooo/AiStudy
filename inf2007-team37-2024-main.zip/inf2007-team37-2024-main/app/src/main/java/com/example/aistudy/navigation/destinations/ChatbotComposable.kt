package com.example.aistudy.navigation.destinations

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.example.aistudy.ui.screens.chatbot.ChatbotScreen
import com.example.aistudy.ui.viewmodels.SharedViewModel
import com.example.aistudy.utils.Constants.CHATBOT_SCREEN

/**
 * Sets up the navigation composable for the Chatbot screen within the app's navigation graph.
 */

fun NavGraphBuilder.chatbotComposable(
    navController: NavHostController,
) {
    composable(route = CHATBOT_SCREEN) {
        // Now passing navController directly to ChatbotScreen
        ChatbotScreen(
            navController = navController
        )
    }
}

