package com.example.aistudy.utils

/**
 * An enumeration of actions that can be performed within the application.
 * These actions include adding, updating, deleting items, deleting all items,
 * undoing the last action, and a fallback option for no action.
 */
enum class Action {
    ADD,
    UPDATE,
    DELETE,
    DELETE_ALL,
    UNDO,
    NO_ACTION
}

/**
 * Converts a nullable String to a corresponding Action enum constant.
 * If the string is null or empty, it defaults to NO_ACTION.
 * Otherwise, it attempts to match the string to an existing Action constant.
 *
 * @return Action corresponding to the string, or NO_ACTION if no match is found.
 */
fun String?.toAction(): Action {
    return if (this.isNullOrEmpty()) Action.NO_ACTION else Action.valueOf(this)
}