# AI Study

Transform your learning experience with AI Study, an innovative Android app designed to cater to diverse learning styles.

![AIStudy](/images/App%20Icon.png)

## Table of Contents
- [About AI Study](#about-ai-study)
- [Getting Started](#getting-started)
- [Key Features](#key-features)
- [Contributors](#contributors)
- [Contributing](#contributing)
- [Contact Us](#contact-us)

## About AI Study

AI Study tackles the challenge of traditional educational methods that often fail to address the full spectrum of learning styles. Our mission is to make learning more inclusive, engaging, and effective for all students by adapting to individual learning preferences and unlocking each student's full potential.

## Getting Started

Follow these steps to set up your development environment for AI Study:

1. **Clone the AI Study repository from GitHub:**

2. **Set up your Android development environment:** Follow the official Android development setup instructions available at the [Android Developers website](https://developer.android.com/studio/install).

3. **Import the project into Android Studio:**
    - Open Android Studio.
    - Click on 'File' > 'New' > 'Import Project'.
    - Navigate to the directory where you cloned the AI Study repository and select the project.

4. **Build and run the app on an Android device or emulator:**
    - Connect your Android device to your computer or launch an emulator.
    - Click on 'Run' > 'Run 'app'' in Android Studio.
    - Choose your device or emulator and wait for the app to launch.

## Key Features

- **Visual Note Capture & AR Visualization:** Engage visual learners with image-based notes and interactive augmented reality experiences.
- **AI-Powered Chatbot:** Facilitate discussions for those who learn best through dialogue.
- **Text-to-Speech:** Support auditory learners by providing text-to-speech functionality.
- **Image-to-Text**: Seamlessly extract text from images for easy integration into your notes.
- **Flexible Note-Taking:** Allow users to capture information in their preferred format – images, text, or audio.

## Contributors

This Project is created with love from these wonderful developers :stars:

<table>
    <tbody>
        <tr>
            <td align="center" valign="top"><a href="https://www.linkedin.com/in/munirrudy/"><img src="/images/Handsome-Munir.JPG" width="100px;" alt="Munir"/><br /><sub><b>Munir</b></a><br><b>President</b></td>
            <td align="center" valign="top"><a href="https://www.linkedin.com/in/nadhirah-binti-ayub-khan-6460b4163/"><img src="/images/neowdirah.jpeg" width="100px;" height="135px;" alt="Nadhirah"/><br /><sub><b>Nadhirah</b></a><br>Vice President</b></td>
            <td align="center" valign="top"><a href="https://tenor.com/j3qyRzIODED.gif"><img src="/images/hamewmew.jpeg" width="100px;" height="135px;" alt="Halilah"/><br /><sub><b>Halilah</b></a><br>Project Manager</b></td>
        </tr>
        <tr>
            <td align="center" valign="top"><a href="https://www.linkedin.com/in/tanhengjoo/"><img src="/images/Joo.JPG" width="100px;" height="135px;" alt="Joo"/><br /><sub><b>Joo</b></a><br>Scrum Master</b></td>
            <td align="center" valign="top"><a href="https://www.linkedin.com/in/alan-wong-0403b6262/"><img src="/images/JanitorIsMe.jpg" width="100px;" height="135px;" alt="Alan"/><br /><sub><b>Alan</b></a><br>Janitor</b></td>
        </tr>
    </tbody>
</table>

## Contact Us

For questions, feedback, or collaborations, reach out to us by our school emails.

Let AI Study supercharge your learning journey!